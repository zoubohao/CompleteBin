
bin_v = "v1.0.6"
