while true; do
echo "touch run"
touch /home/comp/21481598/anaconda3/envs/comebin/lib/python3.7
touch /home/comp/21481598/anaconda3/bin
touch /home/comp/21481598/anaconda3/envs/deepmetabin/lib/python3.9
touch /home/comp/21481598/anaconda3/envs/deepmetabin/lib/python3.9
touch /home/comp/21481598/anaconda3/envs/deepmetabin2/lib/python3.9
touch /home/comp/21481598/anaconda3/envs/deepmetabin/lib/python3.9
touch /home/comp/21481598/anaconda3/envs/deepmetabin/lib/python3.9/site-packages/PIL
touch /home/comp/21481598/anaconda3/envs/deepmetabin2/lib/python3.9/site-packages/PIL
touch /home/comp/21481598/anaconda3/envs/deepmetabin/lib/python3.9/site-packages
touch /home/comp/21481598/anaconda3/envs/deepmetabin2/lib/python3.9/site-packages
touch /home/comp/21481598/anaconda3/envs/deepmetabin2/lib/python3.9/site-packages/checkm2/../tensorflow/python/ops
touch /home/comp/21481598/anaconda3/envs/deepmetabin/lib/python3.9/site-packages/matplotlib
touch /home/comp/21481598/anaconda3/envs/deepmetabin2/lib/python3.9/site-packages/matplotlib
sleep 60;
done